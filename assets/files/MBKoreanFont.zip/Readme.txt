 - 모드 순서 변경 : https://cafe.naver.com/warband/251154, https://cafe.naver.com/warband/251170, 
 - 폴더 이름 확인 : 한글패치가 들어있는 폴더 이름이 MBKoreanFont가 아니면 크래쉬가 납니다.
 - 압축 프로그램 변경 : 최신 버전의 반디집이나 7-zip 으로 압축을 풀어야 문제가 없습니다.

 위의 방법이 다 안 되면 배너로드 자체 문제이거나, 모드간 충돌일 가능성이 높습니다.


   모드 출처 : https://cafe.naver.com/warband / 마공카 한글화팀
